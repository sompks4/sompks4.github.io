October 2012

We provide the replication files for "Trade Liberalization and Embeddeded Institutional Reform: Evidence from Chinese Exporters" (forthcoming, The American Economic Review). The Stata files replicate the Tables 1-5 and Figures 1-3. The matlab files replication the numerical simulations in Section 6 and are used to create Figure 4. These files are to be used for replication purposes only.

Khandelwal, Schott and Wei