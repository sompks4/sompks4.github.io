%solve for equilibrium price indexes by searching until the difference
%between initial and resulting price indexes is close to zero
function res = free(P,a,params)
  
  %given the cutoffs, what are the price indices?
  function Pind = solvepriceind(xstar,a,params)
    tempa = [0 a; 0 0];  
        
    %calculate price index; note: o=origin country; d=destination country
    for o=1:params.N       
      for d=1:params.N     
          
            %find productivities above the cutoff
            active = params.x(params.x>xstar(o,d));    
            index  = find(params.x>xstar(o,d)); 
            
            %if no firms are over the cutoff, set a high price(i.e., a low tmp(d))
            if length(active)==0
                Ptemp(o,d)=1e-10;
                disp('xabove length 0')
            %for firms above cutoff, compute their price and store in "price"
            %then compute the price index using the approximation from IMO (2010) section A.5
            %store the share if firms above cutoff in "shareabove"
            else
                prices      = (params.SIG/(params.SIG-1)) .* ((params.W(o,d)*params.TAU(o,d))./params.x(index) + params.W(o,d)*tempa(o,d)); 
                shareactive = length(active)/length(params.x);                    
                integral    = shareactive * mean(prices.^(1-params.SIG));
                Ptemp(o,d)  = params.DRAWS*integral;        
            end
      end
    end
    Pind(1,:) = sum(Ptemp(:,1))^(1/(1-params.SIG));
    Pind(2,:) = sum(Ptemp(:,2))^(1/(1-params.SIG));
  end

  %find pi and cutoffs simultaneously
  ret        = solve_pi_and_cutoffs(P,a,params);
  xstar_temp = ret(1:end-1);
  pi         = ret(end);
  xstar      = reshape(xstar_temp,params.N,params.N);
  Pnew       = solvepriceind(xstar,a,params);
  res        = Pnew - P;
end
