% Trade Liberalization and Embedded Institutional Reform:
% Evidence from Chinese Exporters
%
% Khandelwal, Schott and Wei 
% May 2011 (main_lognormal_11.m)
%
%
% This program uses output from the lognormal_20121105.m program (which solves the model described in the electronic 
% appendix for the no-quota and efficient-allocation equilibria) to solve for the political-allocation equilibrium
% described in Section 6.3 of the main text.
%


%startup
clear;
clc;
workdir = 'C:\Users\pks4\Documents\My Dropbox\research\mfa\matlab4';
%workdir = 'C:\research\Dropbox\mfa (1)\matlab3'
%workdir = '/user/user1/ak2796/mfa_matlab';
cd(workdir)
path(workdir,path);
format short

%load in output from lognormal_20121105.m; this has the market shares from the auction-allocation
%equilibrium that we will use here, as described in Section 6.3 of the main text
load lognormal_asym_20120509

%set counter
iter            = 1;

%compute total quota quantity
quota_quant    = params.restrictiveness*ftotquant(1,2);

%iterate through the difference correlations of the two draws
%for each correlation, compute the contribution of the implied price decline attributed to the net extensive margin
%pick correlation based on the best-match vis a vis the data, as described in Section 6.3 of the main text 
%this correlation also picks out the TFP of the political-allocation equilibrium
for rho = 1:-.01:-1   
    
    %create PC draw
    temp2          = (log(params.x)-mean(log(params.x)))/std(log(params.x));   %this is for lognormal
    params.pc      = exp(rho*temp2 + sqrt(1-rho^2)*params.norm2);              %this is for lognormal
    draws          = [params.x params.pc];

    %compute true correlation of the two draws
    [rhotrue,pval] = corr(params.pc,params.x,'type','Spearman');
   
    %sort rows by PC draw, from low to high
    [drawspc ipc]  = sortrows(draws,2);
    [drawsx  ix ]  = sortrows(draws,1);
    
    %sort the eff market shares from low to high, adding zeros for no exporters
    [eqshare ieq]  = sortrows([params.eqshare12; zeros(length(draws)-eactive(1,2),1)],1);
    iqshare        = eqshare;
     
    %put the sorted draws along with the inefficient allocation shares of quantity into a single matrix
    %in the last two columns of this matrix, put the free trade q and p (based solely on x)
    %compute prices under inefficient allocation by assuming firms take iq as exogenous and then choose p to cover the fixed and variable costs of trade
    findex = drawspc(:,1)>fxstar(1,2);
    fp     = (params.SIG/(params.SIG-1)).*((params.W(1,2)*params.TAU(1,2))./drawspc(:,1) + params.W(1,2)*0 );
    ip     = (params.SIG/(params.SIG-1)).*((params.W(1,2)*params.TAU(1,2))./drawspc(:,1) + params.W(1,2)*ea);
    ep     = (params.SIG/(params.SIG-1)).*((params.W(1,2)*params.TAU(1,2))./drawspc(:,1) + params.W(1,2)*ea);   
   
    fq     = (params.W(1,2)*params.SIG/(params.SIG-1))^(-params.SIG).*((params.W(1,2)*params.TAU(1,2))./drawspc(:,1) + params.W(1,2)*0 ).^(-params.SIG).*fP(2)^(params.SIG-1).*params.MU*fY(2);
    eq     = (params.W(1,2)*params.SIG/(params.SIG-1))^(-params.SIG).*((params.W(1,2)*params.TAU(1,2))./drawspc(:,1) + params.W(1,2)*ea).^(-params.SIG).*eP(2)^(params.SIG-1).*params.MU*eY(2);  
    iq     = iqshare*quota_quant;
      
    %set the above amounts to zero if the firm is not an exporter
    fq(drawspc(:,1)<=fxstar(1,2)) = 0;
    %fp(drawspc(:,1)<=fxstar(1,2)) = 0;
    eq(drawspc(:,1)<=exstar(1,2)) = 0;
    
    %compute quantity shares
    fqs                            = fq/sum(fq);
    eqs                            = eq/sum(eq);
    iqs                            = iqshare;
    
    %license price scaled by firm prices
    eashare   = (ep-ea)./ep;
    meashare  = mean(eashare(eq(:)>0)); 
    wmeashare = sum(eqs.*eashare); 
    
    %compute the average and weighted average prices overall and then only for incumbents
    %note that the results for e=efficient and i=inefficent will be the same if the correlation is 1
    fpa         = mean(fp(fqs~=0));                  %avg price 
    epa         = mean(ep(eqs~=0));                  %avg price
    ipa         = mean(ip(iqs~=0));                  %avg price
    
    fpw         = sum(fqs.*fp);                      %wavg price 
    epw         = sum(eqs.*ep);                      %wavg price 
    ipw         = sum(iqs.*ip);                      %wavg price 

    ief         = logical(and(eq~=0,fq~=0));
    iif         = logical(and(iq~=0,fq~=0));
    epwi        = sum(eqs(ief).*ep(ief));            %inc wavg price 
    ipwi        = sum(iqs(iif).*ip(iif));            %inc wavg price     
    
    z_akk  = [drawsx];
    %z_pks  = [drawsx iqs eqs fqs ip ep fp];

    %compute price change terms for the decomposition
    %we are interested in two price changes: from e to f and from i to f (we have no time dimension)
    %
    %  note from above that ief and iif are indicators for the intensive
    %  margin from e->f and i->f, respectively
    %
    %  below i also create nef/nif and xef/xif for the entering and exiting
    %  margins, respectively 
    %
    nef         = logical(and(eq==0,fq~=0));
    nif         = logical(and(iq==0,fq~=0));
    xef         = logical(and(eq~=0,fq==0));
    xif         = logical(and(iq~=0,fq==0));
    [sum(ief+nef+xef) sum(iif+nif+xif)];
    sum([ief nef xef iif nif xif]);
    
    Pbar_f   = sum(fqs.*log(fp));     %eq5
    Pbar_e   = sum(eqs.*log(ep));
    Pbar_i   = sum(iqs.*log(ip));
    
    DPbar_ef = Pbar_f - Pbar_e;       %eq6
    DPbar_if = Pbar_f - Pbar_i;
    
    Pbar_ef  = 0.5*(Pbar_e+Pbar_f);   %eq7
    Pbar_if  = 0.5*(Pbar_i+Pbar_f);   
    
    thetabar_ef = 0.5*(eqs + fqs);
    thetabar_if = 0.5*(iqs + fqs);
    
    pbar_ef     = 0.5*(log(ep)  + log(fp));
    pbar_if     = 0.5*(log(ip)  + log(fp));
    
    within_ef = sum( thetabar_ef(ief)    .* (log(fp(ief))-log(ep(ief)))    );
    within_if = sum( thetabar_if(iif)    .* (log(fp(iif))-log(ip(iif)))    );
   
    across_ef = sum( (fqs(ief)-eqs(ief)) .* (pbar_ef(ief)-Pbar_ef)  ); 
    across_if = sum( (fqs(iif)-iqs(iif)) .* (pbar_if(iif)-Pbar_if)  ); 

    n_ef      = sum( fqs(nef)            .* (log(fp(nef)) - Pbar_ef) );
    n_if      = sum( fqs(nif)            .* (log(fp(nif)) - Pbar_if) );
    
    x_ef      = sum( eqs(xef)            .* (log(ep(xef)) - Pbar_ef) );
    x_if      = sum( iqs(xif)            .* (log(ip(xif)) - Pbar_if) );
    
    %check
    %[Pbar_i Pbar_e Pbar_f Pbar_ef Pbar_if];
    %[DPbar_if within_if+across_if+n_if-x_if];
    %[DPbar_ef within_ef+across_ef+n_ef-x_ef];
    %[DPbar_ef within_ef across_ef n_ef x_ef];
    %[DPbar_if within_if across_if n_if x_if];
    
    %decompose quantity growth by margin
    intq_ef = sum(fq(ief)-eq(ief)) / sum(fq-eq);
    entq_ef = sum(fq(nef)-eq(nef)) / sum(fq-eq);
    exiq_ef = sum(fq(xef)-eq(xef)) / sum(fq-eq);

    intq_if = sum(fq(iif)-eq(iif)) / sum(fq-eq);
    entq_if = sum(fq(nif)-eq(nif)) / sum(fq-eq);
    exiq_if = sum(fq(xif)-eq(xif)) / sum(fq-eq);
    
    %check
    %[intq_ef entq_ef exiq_ef  intq_if entq_if exiq_if];
        
    %now compute waverage TFP
    ftfpw = sum(fqs.*drawspc(:,1));
    etfpw = sum(eqs.*drawspc(:,1));
    itfpw = sum(iqs.*drawspc(:,1));

    lftfpw = sum(fqs.*log(drawspc(:,1)));
    letfpw = sum(eqs.*log(drawspc(:,1)));
    litfpw = sum(iqs.*log(drawspc(:,1)));
    
    [lftfpw letfpw litfpw];
    exp([lftfpw letfpw litfpw]);
    [ftfpw etfpw itfpw];
    
    ftfpa = mean(drawspc(fqs~=0,1));
    etfpa = mean(drawspc(eqs~=0,1));
    itfpa = mean(drawspc(iqs~=0,1));
    
    %check
    %[ftfpw etfpw itfpw];
    %[ftfpa etfpa itfpa];

    %market share of top 1% of exporters by size 
    cf      = prctile(fqs(fqs~=0,1),99);
    ce      = prctile(eqs(eqs~=0,1),99);
    ci      = prctile(iqs(iqs~=0,1),99);
    top1exp = [sum(fqs(fqs>cf,1)) sum(eqs(eqs>cf,1)) sum(iqs(iqs>cf,1))];
         
  
    cf2     = prctile(drawspc(fqs(:,1)~=0,1),99);
    ce2     = prctile(drawspc(eqs(:,1)~=0,1),99);
    ci2     = prctile(drawspc(iqs(:,1)~=0,1),99);
   
    top1exp2 = [sum(fqs(and(fqs(:,1)~=0,drawspc(:,1)>cf2),1)) sum(eqs(and(eqs(:,1)~=0,drawspc(:,1)>ce2),1)) sum(iqs(and(iqs(:,1)~=0,drawspc(:,1)>ci2),1))];
  
    
    %market share of top 1% firms by overall tfp
    top1tfp = sum([fqs(drawspc(:,1)>prctile(drawspc(:,1),99)) eqs(drawspc(:,1)>prctile(drawspc(:,1),99)) iqs(drawspc(:,1)>prctile(drawspc(:,1),99))]);
    
    %tfp cutoffs
    [min(drawspc(fqs>0,1)) min(drawspc(eqs>0,1)) min(drawspc(iqs>0,1))];
    
    %report to screen
    %rho rhotrue iavgtfp iwavgtfp ipa ipw ext_share_dpi ext_share_dqi int_dqs            
    report(iter,:) = [rho rhotrue itfpa itfpw ipa ipw (n_if-x_if)/DPbar_if  (entq_if+exiq_if) sum(fqs(iif)-iqs(iif)) ewavgtfp(1,2) fwavgtfp(1,2) top1tfp top1exp];
    %report(iter,:) = [rho rhotrue itfpa itfpw ipa ipw (n_if-x_if)/DPbar_if  (entq_if+exiq_if) sum(fqs(iif)-iqs(iif)) ewavgtfp(1,2) fwavgtfp(1,2) tempsd];
    report;
    
    test = [drawspc fqs eqs iqs];
    csvwrite(strcat('C:\Users\pks4\Documents\My Dropbox\research\mfa\matlab4\r',num2str(iter),'.csv'),test);
   
    iter=iter+1
end

report
csvwrite(strcat(zzz,'.csv'),report);



