%solve for pi and cutoffs "xstar" given the price indexes
function ret = solve_pi_and_cutoffs(P,a,params)

  %this subfunction solves for "pi2" and "xstar2" given "pi1" and "xstar1" in guess
  %it then computes the distance between them; the pi and cutoffs achieved when this distance is ~0 
  %are the solution given the price indexes
  function ret = solve_pi_and_cutoffs2(guess,P,a,params)
    xstar_temp = guess(1:end-1);
    pi         = guess(end);
    xstar      = reshape(xstar_temp,params.N,params.N);
    Y          = params.L*(1+pi);
    xstar2     = calc_cutoff(P,Y,a,params);   
    pi2        = calc_pi(xstar2,params);
    ret        = xstar2(:)-xstar_temp(:);
    ret(end+1) = pi2-pi;
  end

  %this subfunction computes the cutoffs "xstar" given price indexes and license price
  function xstar = calc_cutoff(P,Y,a,params)
    tempa = [0 a; 0 0];
    %added wage x fixed cost here 2011.8.19. added (wage x t) and (wage x tau) 2011.08.22
    xstar = (params.PSI.*repmat(P',params.N,1)./(params.W.*params.TAU).*(params.W.*params.F).^(1/(1-params.SIG)).*repmat(Y',params.N,1).^(1/(params.SIG-1)) - (params.W.*tempa)./(params.W.*params.TAU)).^(-1); 
    
    %xstar = (params.PSI.*repmat(P',params.N,1)./(params.W.*params.TAU).*(          params.F).^(1/(1-params.SIG)).*repmat(Y',params.N,1).^(1/(params.SIG-1)) - tempa./params.TAU).^(-1); 
    if any(any(xstar<0)) 
        disp('Negative Cutoffs');
        xstar(find(xstar<0))=10;
    end
    if isnan(sum(sum(real(xstar))))==1
        disp('Imaginary Cutoffs');
        xstar = [10 14; 22 10];
    end    
  end
  
  %this subfunction calculates little pi (total profit/wL) given cutoffs "xstar"          
  function pi = calc_pi(xstar,params)  
    for o=1:params.N
        for d=1:params.N
            active(o,d) = sum(params.x>xstar(o,d));
        end
    end          
    %pi = (params.MU/params.SIG - sum(sum(active.*params.F))/sum(params.L))/(1-params.MU/params.SIG);  
    pi = (params.MU/params.SIG - sum(sum(active.*(params.W.*params.F)))/sum(params.W(:,1).*params.L))/(1-params.MU/params.SIG);  
  end

  %start here by choosing starting values for xstar and pi
  %first starting value for Y (which depends on pi) is always just L
  %with this guess for Y, you can solve for xstar
  %first starting value for pi is always just .1
  xstar0        = calc_cutoff(P,params.L,a,params);
  guess0        = xstar0(:);
  guess0(end+1) = 0.1;

  %feed the initial "guess0" for pi and cutoffs from last block of code into subfunction "solve_pi_and_cutoffs2"
  %that function solves for pi and cutoffs by minimizing the distance between initial and resulting pis and cutoffs 
  func = @(guess) solve_pi_and_cutoffs2(guess,P,a,params);
  options = optimset('Display','none','MaxIter',1000,'MaxFunEvals',20000,'TolFun',1e-20,'TolX',1e-20);
  [ret,fval,exitflag,output] = fsolve(func,guess0,options); 
  
  %now you are done. pass the distance between initial and resulting pis
  %and cutoffs back to the call for this function back to program "free", 
  %which will use them to figure out when to stop searching over price
  %indexes
  
end