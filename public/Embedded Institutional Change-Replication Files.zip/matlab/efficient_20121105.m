% Use the P0 as starting value.
function f = efficient(a,P,params)
             
    func = @(P) free(P,a,params);
    options1 = optimset('Display','off','MaxIter',1000,'MaxFunEvals',20000);
    [Pind,fval,exitflag,output] = fsolve(func,P,options1); 

    % Find x_x and pi simulaneously
    ret        = solve_pi_and_cutoffs(Pind,a,params);  
    xstar_temp = ret(1:end-1);
    pi         = ret(end);                          
    xstar      = reshape(xstar_temp,params.N,params.N); 
    Y          = params.L*(1+pi);                     

    tempa = [0 a; 0 0];
    o=1;
    d=2;
    
    price   = (params.SIG/(params.SIG-1)) .* ((params.W(o,d)*params.TAU(o,d))./params.x(params.x>xstar(o,d))+params.W(o,d)*tempa(o,d));
    exports = sum(params.MU*Y(d).*(price.^-params.SIG).*Pind(d).^(params.SIG-1));
    
    %now measure how close exports are to the exports
    f = params.ftotquant(o,d)*params.restrictiveness - exports;

end


